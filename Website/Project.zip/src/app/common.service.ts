import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private router:Router) { 
  }
  checkToken():boolean{
    let token = localStorage.getItem('token');
    if (token == undefined || token == ""){
      this.router.navigateByUrl('login');
      return false;
    }else{
      return true;
    }
  }
  behaviourSubject = new BehaviorSubject<string>("");
  
}
