import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { Router } from '@angular/router';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [HeaderComponent,FooterComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
constructor(private rout:Router,private objCommonser:CommonService){
  this.objCommonser.behaviourSubject.subscribe(res=>{
    if(res!=''){
      console.log(res);
    }
  })
  
  let token = localStorage.getItem('token');
    // if (token == undefined || token == ""){
    //   rout.navigateByUrl('login');
    // }
}

eleRes:any[] = [
  {"name":"first Name","type":"text"},
  {"name":"last Name","type":"text"},
  {"name":"choose work mode","type":"radio"},
  {"name":"Country","type":"select","list":["city1","city2","city3"]}
]
}
